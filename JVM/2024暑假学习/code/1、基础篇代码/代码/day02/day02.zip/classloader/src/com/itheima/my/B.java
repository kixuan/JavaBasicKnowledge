package com.itheima.my;

public class B {
    static {
        System.out.println("B类被加载了");
    }
}
