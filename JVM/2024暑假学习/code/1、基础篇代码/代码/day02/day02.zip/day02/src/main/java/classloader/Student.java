package classloader;

public class Student {
}
