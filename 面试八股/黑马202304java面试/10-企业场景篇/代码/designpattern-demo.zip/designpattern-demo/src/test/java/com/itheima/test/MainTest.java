package com.itheima.test;

public class MainTest {

    public static void main(String[] args) {
        System.out.println(666666 % 16384);
        System.out.println(888888 % 16384);
    }
}
