package com.itheima.designpattern.template.simple3;

public interface Coffee {

    public String getName();

    public void addMilk();

    public void addSuqar();
}
