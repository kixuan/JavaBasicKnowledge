package java.lang;

public class String {
    static {
        System.out.println("自己写的String类被加载了...");
    }
}
