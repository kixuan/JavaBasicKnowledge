package com.itheima.jvmoptimize;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JvmOptimizeApplicationTests {

    @Test
    void contextLoads() {
    }

}
