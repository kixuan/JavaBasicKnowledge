package chapter03.stringtable;

/**
 * 字符串常量池案例
 */
public class Demo1 {
    public static void main(String[] args) {
        String a = "123";
        String b = "456";
        String c = new String("789");
    }
}
